package com.example.tanyasehatapp.data.doctor.model

object Doctors {
    val dummy = listOf(
        DoctorModel(
            "Dokter 1",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Umum",
            "5 tahun"
        ),
        DoctorModel(
            "Dokter 2",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Umum",
            "3 tahun"
        ),
        DoctorModel(
            "Dokter 3",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Penyakit Dalam",
            "4 tahun"
        ),
        DoctorModel(
            "Dokter 4",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Anak",
            "5 tahun"
        ),
        DoctorModel(
            "Dokter 5",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Kulit & Kelamin",
            "4 tahun"
        ),
        DoctorModel(
            "Dokter 6",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis THT",
            "6 tahun"
        ),
        DoctorModel(
            "Dokter 7",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Mata",
            "5 tahun"
        ),
        DoctorModel(
            "Dokter 8",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Gigi",
            "7 tahun"
        ),
        DoctorModel(
            "Dokter 9",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Saraf",
            "10 tahun"
        ),
        DoctorModel(
            "Dokter 10",
            "https://img.lovepik.com/original_origin_pic/18/12/07/740398645f2bca8383033881cc3c4b22.png_wh860.png",
            "Spesialis Kandungan & Kebidanan",
            "8 tahun"
        )
    )
}