package com.example.tanyasehatapp.data.doctor.model

data class DoctorModel(
    val doctorname: String,
    val doctorimage: String,
    val doctorspecialty: String,
    val doctoryearexperience: String
)
