package com.example.tanyasehatapp.data.doctor.history

object History {
    val historydummy = listOf(
        HistoryModel(
            "Dokter 1",
            "sakit pinggang dan sakit tenggorokan, badan panas, meriang, demam",
            "12/3/2023",
            "12:30"
        ),
        HistoryModel
        (
            "Dokter 2",
            "sakit gigi saat mengunyah",
            "12/3/2023",
            "19:30"
        ),
        HistoryModel(
            "Dokter 3",
            "telinga berdengung, kadang tidak terdengar apa-apa",
            "15/3/2023",
            "10:00"
        ),
        HistoryModel(
            "Dokter 4",
            "meriang demam, tapi hanya saat malam-malam",
            "15/3/2023",
            "12:00"
        ),
        HistoryModel(
            "Dokter 5",
            "batuk-batuk, demam, meriang, badan sakit",
            "16/3/2023",
            "13:20"
        ),
        HistoryModel(
            "Dokter 6",
            "pusing, sakit kepala hebat dibarengi sakit gigi",
            "16/3/2023",
            "15:15"
        ),
        HistoryModel(
            "Dokter 7",
            "mata berkunang-kunang, berat badan turun drastis",
            "16/3/2023",
            "18:25"
        ),
        HistoryModel(
            "Dokter 8",
            "badan pegal dan biru-biru",
            "17/3/2023",
            "16:50"
        ),
        HistoryModel(
            "Dokter 9",
            "radang tenggorokan, susah menelan, batuk dan pilek",
            "17/3/2023",
            "19:35"
        ),
        HistoryModel(
            "Dokter 10",
            "jerawat besar dan sakit pada hidung",
            "18/3/2023",
            "09:40"
        )
    )
}