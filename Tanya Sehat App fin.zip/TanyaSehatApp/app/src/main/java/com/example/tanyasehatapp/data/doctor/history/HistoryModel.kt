package com.example.tanyasehatapp.data.doctor.history

data class HistoryModel(
    val historydoctorname: String,
    val keluhanhistory: String,
    val tanggalhistory: String,
    val waktuhistory: String
)
